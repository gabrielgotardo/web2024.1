import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import OrderService from "@/service/OrderService";
import AddressService from "@/service/AddressService";
import { IOrderItem, IAddress } from "@/commons/interfaces";
import Footer from "@/components/Footer";
import { FaTruck } from "react-icons/fa";
import Notification from "@/components/Notification";

export function CheckoutPage() {
  const [cart] = useState<IOrderItem[]>(OrderService.getCart());
  const [address, setAddress] = useState<IAddress | null>(null);
  const [pagamento, setPagamento] = useState("dinheiro");
  const [apiError, setApiError] = useState("");
  const [apiSuccess, setApiSuccess] = useState("");
  const [notification, setNotification] = useState<{ message: string; status: "success" | "error" } | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    async function fetchAddress() {
      const response = await AddressService.findOne();
      if (response && response.status === 200) {
        setAddress(response.data);
      } else {
        setApiError("Falha ao buscar endereço de entrega");
        setNotification({ message: "Falha ao buscar endereço de entrega", status: "error" });
      }
    }
    fetchAddress();
  }, []);

  const handleSubmitOrder = async () => {
    const response = await OrderService.submitOrder(pagamento);
    if (response.status === 200) {
      setApiSuccess("Pedido realizado com sucesso!");
      setApiError("");
      setNotification({ message: "Pedido realizado com sucesso!", status: "success" });
      setTimeout(() => {
        navigate("/products");
      }, 3000);
    } else {
      setApiError("Falha ao realizar o pedido");
      setNotification({ message: "Falha ao realizar o pedido", status: "error" });
    }
  };

  const calculateTotal = () => {
    return cart.reduce((total, item) => total + item.product.price * item.quantity, 0);
  };

  return (
    <div className="d-flex flex-column min-vh-100">
      {notification && (
        <Notification
          message={notification.message}
          status={notification.status}
          onClose={() => setNotification(null)}
        />
      )}
      <main className="container flex-grow-1">
        <div className="text-center">
          <span className="h3 mb-3 fw-normal">Resumo do Pedido</span>
        </div>
        <table className="table table-striped">
          <thead>
            <tr>
              <th>Produto</th>
              <th>Quantidade</th>
              <th>Preço unitário</th>
            </tr>
          </thead>
          <tbody>
            {cart.map((item, index) => (
              <tr key={index}>
                <td>{item.product.name}</td>
                <td>{item.quantity}</td>
                <td>R$ {item.product.price.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="text-start mb-3">
          <label htmlFor="pagamento" className="form-label">
            Selecione o método de pagamento:
          </label>
          <select
            id="pagamento"
            value={pagamento}
            onChange={(e) => setPagamento(e.target.value)}
            className="form-control"
          >
            <option value="dinheiro">Dinheiro</option>
            <option value="cartao_credito">Cartão de Crédito</option>
            <option value="cartao_debito">Cartão de Débito</option>
            <option value="pix">PIX</option>
            <option value="boleto">Boleto</option>
          </select>
        </div>
        {address && (
          <div className="mb-3">
            <h4>Endereço de Entrega</h4>
            <p><strong>Rua:</strong> {address.rua}</p>
            <p><strong>Número:</strong> {address.numero}</p>
            <p><strong>Bairro:</strong> {address.bairro}</p>
            <p><strong>Cidade:</strong> {address.cidade}</p>
            <p><strong>CEP:</strong> {address.cep}</p>
          </div>
        )}
        <div className="text-center mb-3 d-flex justify-content-center align-items-center">
          <FaTruck style={{ marginRight: "8px" }} />
          <span style={{ color: "green" }}>Frete Gratuito</span>
        </div>
        <div className="text-center mb-3">
          <h4>Total: R$ {calculateTotal().toFixed(2)}</h4>
        </div>
        <div className="text-center">
          <button className="btn btn-success" onClick={handleSubmitOrder}>
            Finalizar Pedido
          </button>
        </div>
        <div className="text-center mt-3">
          <Link className="btn btn-primary mb-3" to="/cart">
            Voltar ao Carrinho
          </Link>
        </div>
        {apiError && <div className="alert alert-danger">{apiError}</div>}
      </main>
      <Footer />
    </div>
  );
}
