import { IOrder, IOrderItem, IOrdersTela, IProduct } from "@/commons/interfaces";
import { api } from "@/lib/axios";

const orderURL = "/orders";

const getCart = (): IOrderItem[] => {
  const cart = localStorage.getItem("cart");
  return cart ? JSON.parse(cart) : [];
};

const saveCart = (cart: IOrderItem[]) => {
  localStorage.setItem("cart", JSON.stringify(cart));
};

const addToCart = (product: IProduct, quantity: number) => {
  const cart = getCart();
  const existingItem = cart.find(item => item.product.id === product.id);

  if (existingItem) {
    existingItem.quantity += quantity;
  } else {
    cart.push({ product, quantity });
  }

  saveCart(cart);
};

const clearCart = () => {
  localStorage.removeItem("cart");
};

const submitOrder = async (pagamento: string): Promise<any> => {
  const cart = getCart();
  const order: IOrder = {
    pagamento,
    listaItens: cart,
  };

  let response;
  try {
    response = await api.post(`${orderURL}/save`, order);
    if (response.status === 200) {
      clearCart();
    }
  } catch (err: any) {
    response = err.response;
  }
  return response;
};

const getOrders = async (): Promise<IOrdersTela[]> => {
  let response;
  try {
    response = await api.get(`${orderURL}/myorderstela`);
  } catch (err: any) {
    response = err.response;
  }
  return response.data;
};

const OrderService = {
  getCart,
  saveCart,
  addToCart,
  clearCart,
  submitOrder,
  getOrders,
};

export default OrderService;
