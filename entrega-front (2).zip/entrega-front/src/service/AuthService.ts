import { IUserLogin, IUserSignup } from "@/commons/interfaces";

import FingerprintJS from '@fingerprintjs/fingerprintjs';
import { api } from "@/lib/axios";
import Cookies from 'js-cookie';

const fpPromise = FingerprintJS.load();

const getFingerprint = async () => {
  const fp = await fpPromise;
  const result = await fp.get();
  return result.visitorId;
};

const setCookie = (name: string, value: string, days: number) => {
  const expires = new Date(Date.now() + days * 86400000).toUTCString();
  document.cookie = `${name}=${value}; expires=${expires}; path=/`;
};

const getCookie = (name: string) => {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop()?.split(';').shift();
};

const login = async (user: IUserLogin): Promise<any> => {
  let response;
  const fingerprint = await getFingerprint();
  
  try {
    
    response = await api.post("/login", user, {
      headers: { 'Fingerprint': fingerprint }
    });

  
    if (response.status === 200) {
     
      setCookie("token", response.data.token, 7); // Armazenar o token no cookie por 7 dias
      setCookie("fingerprint", fingerprint, 7); // Armazenar o fingerprint no cookie por 7 dias
      api.defaults.headers.common["Authorization"] = `Bearer ${response.data.token}`;
      api.defaults.headers.common["Fingerprint"] = fingerprint;

    }
  } catch (error: any) {
    response = error.response;
  }

  return response;
};

const isAuthenticated = async (): Promise<boolean> => {
  const token = getCookie("token");
  const fingerprint = await getFingerprint();
  
  if (token && fingerprint) {
    api.defaults.headers.common["Authorization"] = `Bearer ${token}`;
    api.defaults.headers.common["Fingerprint"] = fingerprint;
    try {
      const response = await api.get('/users/validateToken');
      if (response.status === 200) {
        return true;
      } else {
        document.cookie = "token=; expires=Thu, 01 Jan 1970 00:00:00 GMT";
        document.cookie = "fingerprint=; expires=Thu, 01 Jan 1970 00:00:00 GMT";
        return false;
      }
    } catch (error) {
      document.cookie = "token=; expires=Thu, 01 Jan 1970 00:00:00 GMT";
      document.cookie = "fingerprint=; expires=Thu, 01 Jan 1970 00:00:00 GMT";
      return false;
    }
  } else {
    return false;
  }
};

const signup = async (user: IUserSignup): Promise<any> => {
  let response;
  try {
    response = await api.post("/users", user);
  } catch (error: any) {
    response = error.response;
  }
  return response;
};

const logout = (): void => {
  document.cookie = "token=; expires=Thu, 01 Jan 1970 00:00:00 GMT";
  document.cookie = "fingerprint=; expires=Thu, 01 Jan 1970 00:00:00 GMT";
  api.defaults.headers.common["Authorization"] = "";
  api.defaults.headers.common["Fingerprint"] = "";
};

const AuthService = {
  signup,
  login,
  isAuthenticated,
  logout,
};

export default AuthService;
