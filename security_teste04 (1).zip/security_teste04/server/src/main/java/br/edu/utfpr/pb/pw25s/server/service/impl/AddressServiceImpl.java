package br.edu.utfpr.pb.pw25s.server.service.impl;

import br.edu.utfpr.pb.pw25s.server.model.Address;
import br.edu.utfpr.pb.pw25s.server.model.User;
import br.edu.utfpr.pb.pw25s.server.repository.AddressRepository;
import br.edu.utfpr.pb.pw25s.server.service.IAddressService;
import br.edu.utfpr.pb.pw25s.server.service.UserService;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class AddressServiceImpl extends CrudServiceImpl<Address, Long> implements IAddressService {


    private final AddressRepository addressRepository;
    private final UserService userService;
    public AddressServiceImpl(AddressRepository addressRepository, UserService userService) {
        this.addressRepository = addressRepository;
        this.userService = userService;
    }

    @Override
    protected JpaRepository<Address, Long> getRepository() {
        return addressRepository;
    }



    public Address buscarAddress(){

        List<Address> addressList = addressRepository.findByUserId(userService.getUserDoToken().getId());

     Address address =   addressList.get(0);

        return address;

    }

    public void salvarAddress(Address address){

        addressRepository.deleteByUserId(userService.getUserDoToken().getId());

        address.setUser(userService.getUserDoToken());

        addressRepository.save(address);

    }

    public void saveStart(User user){

        Address address = new Address();
        address.setUser(user);
        address.setCep("-");
        address.setCidade("-");
        address.setRua("-");
        address.setNumero("-");
        address.setBairro("-");
        save(address);
    }


}
