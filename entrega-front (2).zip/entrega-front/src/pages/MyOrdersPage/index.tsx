import { useEffect, useState } from "react";
import OrderService from "@/service/OrderService";
import { IOrdersTela, IProductTela } from "@/commons/interfaces";
import Footer from "@/components/Footer";
import { Accordion, AccordionItem, AccordionButton, AccordionPanel, Box, Text, Flex, Icon } from "@chakra-ui/react";
import { MdExpandMore } from "react-icons/md";
import Notification from "@/components/Notification";

export function OrdersPage() {
  const [orders, setOrders] = useState<IOrdersTela[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>("");
  const [notification, setNotification] = useState<{ message: string; status: "success" | "error" } | null>(null);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const ordersData = await OrderService.getOrders();
        setOrders(ordersData);
      } catch (err) {
        setError("Erro ao carregar pedidos");
        setNotification({ message: "Erro ao carregar pedidos", status: "error" });
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, []);

  if (loading) {
    return <div>Carregando...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", minHeight: "100vh" }}>
      {notification && (
        <Notification
          message={notification.message}
          status={notification.status}
          onClose={() => setNotification(null)}
        />
      )}
      <div className="container" style={{ flex: 1 }}>
        <h1 className="text-center mt-8 mb-4 text-3xl font-semibold">Meus Pedidos</h1>
        {orders.length === 0 ? (
          <p className="text-center">Você ainda não fez nenhum pedido finalizado.</p>
        ) : (
          <Accordion allowToggle>
            {orders.map((order, index) => {
              const totalValue = order.productTelas.reduce((total, item) => total + item.priceU, 0).toFixed(2);

              return (
                <AccordionItem key={index} border="1px" borderColor="gray.200" borderRadius="lg" mb={4}>
                  <h2>
                    <AccordionButton _expanded={{ bg: "blue.500", color: "white" }}>
                      <Flex flex="1" align="center" justify="space-between">
                        <Box>
                          <Text fontSize="lg">
                            Pedido {index + 1} - Data: {new Date(order.data).toLocaleDateString()} - Valor Total: R${totalValue}
                          </Text>
                        </Box>
                        <Icon as={MdExpandMore} />
                      </Flex>
                    </AccordionButton>
                  </h2>
                  <AccordionPanel pb={4}>
                    <Text mb={2} fontSize="lg" fontWeight="bold">Detalhes do Pedido:</Text>
                    <Text><strong>Forma de Pagamento:</strong> {order.pagamento}</Text>
                    <Text mb={2}><strong>Itens:</strong></Text>
                    <ul>
                      {order.productTelas.map((item: IProductTela, itemIndex) => (
                        <li key={itemIndex}>
                          <Text><strong>Nome:</strong> {item.descricao} ({item.quantity} unidade(s))</Text>
                          <Text><strong>Preço Pago:</strong> R${item.priceU.toFixed(2)}</Text>
                        </li>
                      ))}
                    </ul>
                  </AccordionPanel>
                </AccordionItem>
              );
            })}
          </Accordion>
        )}
      </div>
      <Footer />
    </div>
  );
}
