import  { useEffect, useState } from "react";
import {  useNavigate } from "react-router-dom";
import { IProduct, ICategory } from "@/commons/interfaces";
import logo from "@/assets/img/3.jpg";
import ProductService from "@/service/ProductService";
import CategoryService from "@/service/CategoryService";
import { NavBar } from "@/components/NavBar";
import {
  Box,
  Button,
  Flex,
  Grid,
  Heading,
  Image,
  Stack,
  Text,
  Alert,
  AlertIcon,
  Spinner,
  HStack,
  Icon,
} from "@chakra-ui/react";
import { StarIcon } from "@chakra-ui/icons";
import Footer from "@/components/Footer";

export function ProductListPage() {
  const [data, setData] = useState<IProduct[]>([]);
  const [categories, setCategories] = useState<ICategory[]>([]);
  const [apiError, setApiError] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [itemsPerPage] = useState(8);
  const navigate = useNavigate();

  const { findAll, findByCategory } = ProductService;

  useEffect(() => {
    loadCategories();
    loadData();
  }, []);

  const loadData = async (categoryId?: number) => {
    setLoading(true);
    let response;
    if (categoryId) {
      response = await findByCategory({ id: categoryId, name: "", desconto: 0 });
    } else {
      response = await findAll();
    }

    if (response.status === 200) {
      setData(response.data);
      setApiError("");
    } else if (response.status === 204) {
      setData([]);
      setApiError("");
    } else {
      setApiError("Falha ao carregar a lista de produtos");
    }
    setLoading(false);
  };

  const loadCategories = async () => {
    const response = await CategoryService.findAll();
    if (response.status === 200) {
      setCategories(response.data);
    } else {
      setApiError("Falha ao carregar a lista de categorias");
    }
  };

  const handleCategoryClick = (categoryId?: number) => {
    loadData(categoryId);
    setCurrentPage(1);
  };

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = data.slice(indexOfFirstItem, indexOfLastItem);

  const pageNumbers = [];
  for (let i = 1; i <= Math.ceil(data.length / itemsPerPage); i++) {
    pageNumbers.push(i);
  }

  const paginate = (pageNumber: number) => setCurrentPage(pageNumber);

  const renderRating = (rating: number) => {
    return (
      <HStack spacing={1}>
        {[...Array(5)].map((_, i) => (
          <Icon
            key={i}
            as={StarIcon}
            color={i < rating ? "yellow.400" : "gray.300"}
          />
        ))}
      </HStack>
    );
  };

  const handleCardClick = (productId?: number) => {
    if (productId !== undefined) {
      navigate(`/products/${productId}`);
    }
  };

  return (
    <>
      <NavBar />
      <Box
        p={5}
        backgroundImage={`url(${logo})`}
        backgroundSize="cover"
        backgroundPosition="center"
      >
        <Heading textAlign="center" mb={5} color="white">
          Bem-vindo à família FISHBONE 
        </Heading>
        <Flex justifyContent="center" mb={5}>
          <Button onClick={() => handleCategoryClick()} mr={2}>
            Todas as Categorias
          </Button>
          {categories.map((category) => (
            <Button key={category.id} onClick={() => handleCategoryClick(category.id)} mr={2}>
              {category.name}
            </Button>
          ))}
        </Flex>
        {loading ? (
          <Flex justifyContent="center">
            <Spinner size="xl" />
          </Flex>
        ) : (
          <>
            <Grid templateColumns="repeat(4, 1fr)" gap={6}>
              {currentItems.length > 0 ? (
                currentItems.map((product: IProduct) => {
                  const originalPrice = product.price;
                  const discount = product.category?.desconto || 0;
                  const discountedPrice = originalPrice + (originalPrice * discount / 100);

                  return (
                    <Box
                      key={product.id}
                      borderWidth="1px"
                      borderRadius="lg"
                      overflow="hidden"
                      p={5}
                      boxShadow="lg"
                      bg="lightblue"
                      _hover={{ bg: "gray.100", cursor: "pointer" }}
                      onClick={() => handleCardClick(product.id)}
                    >
                      <Flex justifyContent="center" mb="4">
                        <Image
                          src={`data:image/jpeg;base64,${product.url}`}
                          alt={product.name}
                          boxSize="250px"
                          objectFit="cover"
                        />
                      </Flex>
                      <Stack spacing="3">
                        <Heading size="md">{product.name}</Heading>
                        <Text>{product.description}</Text>
                        <Text color="red.500" textDecoration="line-through">
                          De R$ {discountedPrice.toFixed(2)}
                        </Text>
                        <Text color="green.500">Por R$ {product.price.toFixed(2)}</Text>
                        <Text>Categoria: {product.category?.name}</Text>
                        {renderRating(product.rating)}
                      </Stack>
                    </Box>
                  );
                })
              ) : (
                <Text textAlign="center" w="full" color="white">
                  Nenhum produto encontrado.
                </Text>
              )}
            </Grid>
            <Flex justifyContent="center" mt={5}>
              {pageNumbers.map((number) => (
                <Button
                  key={number}
                  onClick={() => paginate(number)}
                  mr={2}
                  disabled={currentPage === number}
                >
                  {number}
                </Button>
              ))}
            </Flex>
          </>
        )}
        {apiError && (
          <Alert status="error" mt={5}>
            <AlertIcon />
            {apiError}
          </Alert>
        )}
      </Box>
      <Footer/>
    </>
  );
}
