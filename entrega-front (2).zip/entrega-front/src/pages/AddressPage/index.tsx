import React, { useEffect, useState } from "react";
import AddressService from "@/service/AddressService";
import { IAddress } from "@/commons/interfaces";
import { useNavigate } from "react-router-dom";
import Footer from "@/components/Footer";
import { Box, Button, Container, FormControl, FormLabel, Input, Text } from "@chakra-ui/react";
import Notification from "@/components/Notification";  

export function AddressPage() {
  const [address, setAddress] = useState<IAddress>({
    rua: "",
    cep: "",
    numero: "",
    cidade: "",
    bairro: ""
  });
  const [loading, setLoading] = useState<boolean>(true);
  const [apiError, setApiError] = useState("");
  const [notification, setNotification] = useState<{ message: string; status: "success" | "error" } | null>(null);  
  const navigate = useNavigate();

  useEffect(() => {
    const fetchAddress = async () => {
      setLoading(true);
      try {
        const response = await AddressService.findOne();
        setAddress(response.data);
        setApiError("");
      } catch (error) {
        setApiError("Falha ao carregar o endereço");
      } finally {
        setLoading(false);
      }
    };

    fetchAddress();
  }, []);

  const handleSave = async () => {
    const response = await AddressService.save(address);
    if (response.status === 200) {
      setNotification({ message: "Endereço alterado com sucesso!", status: "success" });
    } else {
      setApiError("Erro ao salvar o endereço");
      setNotification({ message: "Erro ao salvar o endereço", status: "error" });
    }
  };

  const onChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = event.target;
    setAddress((prevAddress) => ({
      ...prevAddress,
      [name]: value,
    }));
  };

  if (loading) {
    return <div>Carregando...</div>;
  }

  return (
    <>
      {notification && (
        <Notification
          message={notification.message}
          status={notification.status}
          onClose={() => setNotification(null)}
        />
      )}
      <Container maxW="lg" mt="8">
        <Text fontSize="3xl" textAlign="center" mb="6">Endereço</Text>
        <Box>
          <FormControl>
            <FormLabel htmlFor="rua">Rua</FormLabel>
            <Input
              type="text"
              id="rua"
              name="rua"
              value={address.rua}
              onChange={onChange}
              variant="filled"
            />
          </FormControl>
          <FormControl mt="4">
            <FormLabel htmlFor="cep">CEP</FormLabel>
            <Input
              type="text"
              id="cep"
              name="cep"
              value={address.cep}
              onChange={onChange}
              variant="filled"
            />
          </FormControl>
          <FormControl mt="4">
            <FormLabel htmlFor="numero">Número</FormLabel>
            <Input
              type="text"
              id="numero"
              name="numero"
              value={address.numero}
              onChange={onChange}
              variant="filled"
            />
          </FormControl>
          <FormControl mt="4">
            <FormLabel htmlFor="cidade">Cidade</FormLabel>
            <Input
              type="text"
              id="cidade"
              name="cidade"
              value={address.cidade}
              onChange={onChange}
              variant="filled"
            />
          </FormControl>
          <FormControl mt="4">
            <FormLabel htmlFor="bairro">Bairro</FormLabel>
            <Input
              type="text"
              id="bairro"
              name="bairro"
              value={address.bairro}
              onChange={onChange}
              variant="filled"
            />
          </FormControl>
        </Box>
        <Box mt="6" textAlign="center">
          <Button colorScheme="green" onClick={handleSave}>Salvar Endereço</Button>
        </Box>
        {apiError && <Text color="red.500" mt="4">{apiError}</Text>}
        <Box mt="6" textAlign="center">
          <Button colorScheme="blue" onClick={() => navigate("/home")}>Voltar</Button>
        </Box>
      </Container>
      <Box mt="4"> {}
        <Footer />
      </Box>
    </>
  );
}
