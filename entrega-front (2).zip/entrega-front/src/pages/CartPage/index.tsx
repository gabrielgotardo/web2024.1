import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import OrderService from "@/service/OrderService";
import { IOrderItem } from "@/commons/interfaces";
import { NavBar } from "@/components/NavBar";
import Footer from "@/components/Footer";
import Notification from "@/components/Notification"; 

export function CartPage() {
  const [cart, setCart] = useState<IOrderItem[]>([]);
  const [notification, setNotification] = useState<{ message: string; status: "success" | "error" } | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    setCart(OrderService.getCart());
  }, []);

  const handleIncreaseQuantity = (index: number) => {
    const newCart = [...cart];
    newCart[index].quantity += 1;
    setCart(newCart);
    OrderService.saveCart(newCart);
  };

  const handleDecreaseQuantity = (index: number) => {
    const newCart = [...cart];
    if (newCart[index].quantity > 1) {
      newCart[index].quantity -= 1;
      setCart(newCart);
      OrderService.saveCart(newCart);
    }
  };

  const handleRemoveItem = (index: number) => {
    const newCart = cart.filter((_, i) => i !== index);
    setCart(newCart);
    OrderService.saveCart(newCart);
    setNotification({ message: "Item removido com sucesso!", status: "success" });
  };

  const handleClearCart = () => {
    setCart([]);
    OrderService.clearCart();
    setNotification({ message: "Carrinho limpo com sucesso!", status: "success" });
  };

  const handleCheckout = () => {
    navigate("/checkout");
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", minHeight: "100vh" }}>
      {notification && (
        <Notification
          message={notification.message}
          status={notification.status}
          onClose={() => setNotification(null)}
        />
      )}
      <NavBar />
      <main className="container" style={{ flex: 1 }}>
        <div className="text-center">
          <span className="h3 mb-3 fw-normal">Carrinho de Compras</span>
        </div>
        <table className="table table-striped">
          <thead>
            <tr>
              <th>Produto</th>
              <th>Quantidade</th>
              <th>Preço unitário</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
            {cart.map((item, index) => (
              <tr key={index}>
                <td>{item.product.name}</td>
                <td>{item.quantity}</td>
                <td>R$ {item.product.price.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                <td>
                  <button className="btn btn-secondary me-2" onClick={() => handleIncreaseQuantity(index)}>+</button>
                  <button className="btn btn-secondary me-2" onClick={() => handleDecreaseQuantity(index)}>-</button>
                  <button className="btn btn-danger" onClick={() => handleRemoveItem(index)}>Remover</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="text-center">
          <button className="btn btn-danger me-2" onClick={handleClearCart}>Limpar Carrinho</button>
          <button className="btn btn-success" onClick={handleCheckout}>Finalizar Pedido</button>
        </div>
        <div className="text-center mt-3">
          <Link className="btn btn-primary" to="/products">
            Continuar Comprando
          </Link>
        </div>
      </main>
      <Footer />
    </div>
  );
}
