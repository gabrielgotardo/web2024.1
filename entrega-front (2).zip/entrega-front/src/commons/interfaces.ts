export interface IUserSignup {
  displayName: string;
  username: string;
  password: string;
  email: string;
}

export interface IUserLogin {
  username: string;
  password: string;
  totp: string;
}

export interface ICategory {
  id?: number;
  name: string;
  desconto: number;
}

export interface IProduct {
  id?: number;
  name: string;
  description: string;
  price: number;
  category: ICategory;
  url: string;
  rating: number;
}

export interface IOrderItem {
  product: IProduct;
  quantity: number;
}

export interface IOrder {
  pagamento: string;
  listaItens: IOrderItem[];
}


export interface IAddress {
  id?: number;
  rua: string;
  cep: string;
  numero: string;
  cidade: string;
  bairro: string;
}

export interface IProductTela {
  descricao: string;
  priceU: number;
  quantity: number;
}

export interface IOrdersTela {
  data: Date;
  pagamento: string;
  productTelas: IProductTela[];
}







