import { ICategory } from "@/commons/interfaces";
import { api } from "@/lib/axios";

const productURL = "/products";

const findAll = async (): Promise<any> => {
  let response;
  try {
    response = await api.get(productURL, {
      headers: {
        Authorization: null
      }
    });
  } catch (err: any) {
    response = err.response;
  }
  return response;
};

const findByCategory = async (category: ICategory): Promise<any> => {
  let response;
  try {
    response = await api.get(`/products/category/${category.id}`, {
      headers: {
        Authorization: null
      }
    });
  } catch (err: any) {
    response = err.response;
  }
  return response;
};

const findOne = async (id: number): Promise<any> => {
  let response;
  try {
    response = await api.get(`${productURL}/${id}`, {
      headers: {
        Authorization: null
      }
    });
  } catch (err: any) {
    response = err.response;
  }
  return response;
};

const ProductService = {
  findAll,
  findOne,
  findByCategory,
};

export default ProductService;
