package br.edu.utfpr.pb.pw25s.server.dto;

import br.edu.utfpr.pb.pw25s.server.model.Product;
import lombok.Data;

import java.math.BigDecimal;




@Data
public class ProductTela {

    private String descricao;
    private BigDecimal priceU;
    private Integer quantity;


}
