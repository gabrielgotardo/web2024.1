import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { IProduct } from "@/commons/interfaces";
import ProductService from "@/service/ProductService";
import OrderService from "@/service/OrderService";
import { NavBar } from "@/components/NavBar";
import { Box, Flex, Heading, Image, Text, Button, Alert, AlertIcon, Spinner, HStack, Icon } from "@chakra-ui/react";
import { StarIcon } from "@chakra-ui/icons";
import Footer from "@/components/Footer";
import Notification from "@/components/Notification";

export function ProductDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState<IProduct | null>(null);
  const [apiError, setApiError] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [notification, setNotification] = useState<{ message: string; status: "success" | "error" } | null>(null);

  useEffect(() => {
    if (id) {
      loadProduct(parseInt(id));
    }
  }, [id]);

  const loadProduct = async (productId: number) => {
    const response = await ProductService.findOne(productId);
    if (response.status === 200) {
      setProduct(response.data);
      setApiError("");
    } else {
      setApiError("Falha ao carregar os detalhes do produto");
      setNotification({ message: "Falha ao carregar os detalhes do produto", status: "error" });
    }
  };

  const handleAddToCart = () => {
    if (product) {
      OrderService.addToCart(product, quantity);
      setNotification({ message: "Produto adicionado ao carrinho!", status: "success" });
    }
  };

  const renderRating = (rating: number) => {
    return (
      <HStack spacing={1}>
        {[...Array(5)].map((_, i) => (
          <Icon
            key={i}
            as={StarIcon}
            color={i < rating ? "yellow.400" : "gray.300"}
          />
        ))}
      </HStack>
    );
  };

  if (!product) {
    return (
      <Flex justifyContent="center" alignItems="center" height="100vh">
        <Spinner size="xl" />
      </Flex>
    );
  }

  const originalPrice = product.price;
  const discount = product.category?.desconto || 0;
  const discountedPrice = originalPrice + (originalPrice * discount / 100);
  const discountValue = discountedPrice - originalPrice ;
  const installmentValue = discountedPrice / 6;

  return (
    <>
      <NavBar />
      {notification && (
        <Notification
          message={notification.message}
          status={notification.status}
          onClose={() => setNotification(null)}
        />
      )}
      <Box p={5}>
        <Heading textAlign="center" mb={5} color="teal.600">
          {product.name}
        </Heading>
        <Flex justifyContent="center" flexDirection={{ base: "column", md: "row" }} alignItems="center">
          <Box maxW="500px" mb={{ base: 5, md: 0 }}>
            <Image src={`data:image/jpeg;base64,${product.url}`} alt={product.name} borderRadius="lg" />
          </Box>
          <Box ml={{ base: 0, md: 8 }}>
            <Text fontSize="xl" fontWeight="bold" textDecoration="line-through" color="red.500">
              R$ {discountedPrice.toFixed(2)}
            </Text>
            <Text fontSize="2xl" fontWeight="bold" color="green.500">
              R$ {originalPrice.toFixed(2)}
            </Text>
            <Text fontSize="lg" mt={2} color="gray.700">Valor economizado de <b>R$ {discountValue.toFixed(2)}</b></Text>
            <Text fontSize="lg" mt={2} color="gray.700">Parcelamento em até <b>6x de R$ {installmentValue.toFixed(2)}</b> sem juros</Text>
            <Text fontSize="md" mt={2} color="gray.600">{product.description}</Text>
            <Flex alignItems="center" mt={4}>
              {renderRating(product.rating)}
            </Flex>
            <Flex alignItems="center" mt={4}>
              <Text fontSize="md" mr={2} color="gray.700">Quantidade:</Text>
              <input
                type="number"
                value={quantity}
                min="1"
                onChange={(e) => setQuantity(parseInt(e.target.value))}
                className="form-control"
                style={{ width: "80px", padding: "5px", border: "1px solid #ccc", borderRadius: "4px" }}
              />
            </Flex>
            <Button colorScheme="green" mt={4} onClick={handleAddToCart}>Adicionar ao Carrinho</Button>
            <Link to="/cart" style={{ textDecoration: "none" }}>
              <Button colorScheme="blue" mt={4} ml={2}>Ver Carrinho</Button>
            </Link>
          </Box>
        </Flex>
        {apiError && (
          <Alert status="error" mt={5}>
            <AlertIcon />
            {apiError}
          </Alert>
        )}
      </Box>
      <Footer />
    </>
  );
}
