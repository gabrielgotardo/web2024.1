package br.edu.utfpr.pb.pw25s.server.service;

import br.edu.utfpr.pb.pw25s.server.model.Category;

public interface ICategoryService extends ICrudService<Category, Long> {


}
