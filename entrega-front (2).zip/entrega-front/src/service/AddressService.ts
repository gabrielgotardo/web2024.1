import { IAddress } from "@/commons/interfaces";
import { api } from "@/lib/axios";

const addressURL = "/address";

const save = async (address: IAddress): Promise<any> => {
  let response;
  try {
    response = await api.post(addressURL, address);
  } catch (err: any) {
    response = err.response;
  }
  return response;
};

const findOne = async (): Promise<any> => {
  let response;
  try {
    response = await api.get(addressURL);
  } catch (err: any) {
    response = err.response;
  }
  return response;
};

const AddressService = {
  save,
  findOne,
};

export default AddressService;
